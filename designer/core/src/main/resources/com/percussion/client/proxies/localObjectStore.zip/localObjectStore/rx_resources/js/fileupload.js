// FILE UPLOAD FUNCTIONS - added by Percussion Software


function Submit_onclick() {
var posn;
var i;
var fldval;
var fldname;
var extension;

fldname = "";
fldval = document.newfileupload.fileupload.value;
posn = document.newfileupload.fileupload.value.length;

if(posn > 0) {
  for(i= posn-1; i>0; i--) {

		if (fldval.charAt(i) != '.') {
		extension = fldname;
		fldname = fldval.charAt(i) + fldname;

		}

		if (fldval.charAt(i) == '.') {
			i = 0;
			document.newfileupload.extension.value = fldname;
            document.newfileupload.submit();
			
		}
	  }
	}
	else {
          alert('Sorry, no file selected.');
          document.newfileupload.fileupload.focus()
  }
        
}




function openWindow(URL) {

var WindowAttribs="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=550,top=100,left=300"
child = window.open(URL,"LinkSite",WindowAttribs)
	return;
  }



function Update_onclick() {
var posn;
var i;
var fldval;
var fldname;
var extension;

fldname = "";
fldval = document.editfileupload.fileupload.value;
posn = document.editfileupload.fileupload.value.length;

if(posn > 0) {
  for(i= posn-1;i>0; i--) {

		if (fldval.charAt(i) != '.') {
		extension = fldname;
		fldname = fldval.charAt(i) + fldname;

		}
		
            if (fldval.charAt(i) == '.') {
		       i = 0;
			document.editfileupload.extension.value = fldname;
			if  (document.editfileupload.extension.value=='') {
	           alert('Sorry, no file selected.');
	           return false } 
			 document.editfileupload.submit();
			
		}
		
	  }
	  
	  if  (document.editfileupload.extension.value=='') 
	  { alert('Sorry, no file selected.');
	   } 
	}
	else {
	
         document.editfileupload.submit();
  }
     
}

