// FILE UPLOAD FUNCTIONS - added by Percussion Software


function val_textfield() {

}
