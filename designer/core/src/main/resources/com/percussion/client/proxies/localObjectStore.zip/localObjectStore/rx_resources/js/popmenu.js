/**
 *  This file is used to write user defined javascript functions.
 * 
 */