All of the necessary ewebeditpro files are in the /Tools/Ektron/ewebeditpro.jar


To modify ewebeditprofiles:

CHECKOUT PROCEDURE
1. checkout /Tools/Ektron/ewebeditpro.jar
2. pull out files that need to be modified out of the /Tools/Ektron/ewebeditpro.jar
3. check in modified files into this directory.

CHECKIN PROCEDURE

- When ready to check in the modified files, check in the new files into the corresponding location in the ewebeditpro directory. 
If the corresponding location does not exist, create the correct directory structure in the ewebeditpro directory.