// IMAGE UPLOAD FUNCTIONS - added by Percussion Software


function Submit_onclick() {
var posn;
var i;
var fldval;
var fldname;
var extension;

fldname = "";
fldval = document.newimageupload.imageupload.value;
posn = document.newimageupload.imageupload.value.length;

if(posn > 0) {
  for(i= posn-1;i>0; i--) {

		if (fldval.charAt(i) != '.') {
		extension = fldname;
		fldname = fldval.charAt(i) + fldname;

		}
		
            if (fldval.charAt(i) == '.') {
		       i = 0;
			document.newimageupload.extension.value = fldname;
			if  (document.newimageupload.extension.value=='') {
	           alert('Sorry, no file selected.');
	           return false } 
			 document.newimageupload.submit();
			
		}
		
	  }
	  
	  if  (document.newimageupload.extension.value=='') 
	  { alert('Sorry, no file selected.');
	   } 
	}
	else {
	       alert('Sorry, no file selected.');
         //document.newimageupload.submit();
  }
     
}


